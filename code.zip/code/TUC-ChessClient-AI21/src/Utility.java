import java.util.ArrayList;
import java.lang.Math;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Date;

public class Utility {
    private int rows = 7;
	private int columns = 5;
    private int rookBlocks = 3;
    private int maxDepth = 6;
    private int abMaxDepth = 13;
	private int pruneDepth = 4;
	private int singularExtensionDepth = 9;
    private int pawnScore = 1;
	private int rookScore = 3;
	private int kingScore = 8;
    private double presentScore = 0.9;
    private int noPrize = 9;
	private double c = Math.sqrt(2);
	private TreeNode MCTSTree = null;

    public Utility() {

    }

	public String boardToString(String[][] board) {
		String boardAsString = "";
		int i, j;

		for(i = 0; i < board.length; i++) {
			for(j = 0; j < board[i].length; j++) {
				boardAsString += board[i][j];
			}
		}

		return boardAsString;
	}

	private ArrayList<String> sortMoves(ArrayList<String> moves, String[][] board) {
		if(moves.size() == 0)
			return moves;
		ArrayList<String> sortedMoves = moves;
		ArrayList<Double> moveScore = new ArrayList<Double>();
		double score = 0;

		for(int i = 0; i < moves.size(); i++) {
			int x2 = Integer.parseInt(String.valueOf(moves.get(i).charAt(2)));
			int y2 = Integer.parseInt(String.valueOf(moves.get(i).charAt(3)));
			if(board[x2][y2] == "P") {
				score = (double)presentScore;
			} else if(board[x2][y2] == "WP" || board[x2][y2] == "BP") {
				score = (double)pawnScore;
			} else if(board[x2][y2] == "WR" || board[x2][y2] == "BR") {
				score = (double)rookScore;
			} else if(board[x2][y2] == "WK" || board[x2][y2] == "BK") {
				score = (double)kingScore;
			} else {
				score = 0;
			}
			moveScore.add(score);
		}
		
		Collections.sort(sortedMoves, Comparator.comparing(s -> -moveScore.get(sortedMoves.indexOf(s))));

		return sortedMoves;
	}

    public ArrayList<String> whiteMovesNewBoard(String[][] board) {
        ArrayList<String> availableMoves = new ArrayList<String>();
        String firstLetter = "";
		String secondLetter = "";
		String move = "";

		for(int i=0; i<rows; i++)
		{
			for(int j=0; j<columns; j++)
			{
				firstLetter = Character.toString(board[i][j].charAt(0));

				// if it there is not a white chess part in this position then keep on searching
				if(firstLetter.equals("B") || firstLetter.equals(" ") || firstLetter.equals("P"))
					continue;
				
				// check the kind of the white chess part
				secondLetter = Character.toString(board[i][j].charAt(1));
				
				if(secondLetter.equals("P"))	// it is a pawn
				{
					
					// check if it can move one vertical position ahead
					firstLetter = Character.toString(board[i-1][j].charAt(0));
					
					if(firstLetter.equals(" ") || firstLetter.equals("P"))
					{
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i-1) + Integer.toString(j);
						
						availableMoves.add(move);
					}
					
					// check if it can move crosswise to the left
					if(j!=0 && i!=0)
					{
						firstLetter = Character.toString(board[i-1][j-1].charAt(0));						
						if(!(firstLetter.equals("W") || firstLetter.equals(" ") || firstLetter.equals("P"))) {
							move = Integer.toString(i) + Integer.toString(j) + 
									   Integer.toString(i-1) + Integer.toString(j-1);
								
							availableMoves.add(move);
						}											
					}
					
					// check if it can move crosswise to the right
					if(j!=columns-1 && i!=0)
					{
						firstLetter = Character.toString(board[i-1][j+1].charAt(0));
						if(!(firstLetter.equals("W") || firstLetter.equals(" ") || firstLetter.equals("P"))) {
							
							move = Integer.toString(i) + Integer.toString(j) + 
									   Integer.toString(i-1) + Integer.toString(j+1);							
							availableMoves.add(move);
						}
					}
				}
				else if(secondLetter.equals("R"))	// it is a rook
				{
					// check if it can move upwards
					for(int k=0; k<rookBlocks; k++)
					{
						if((i-(k+1)) < 0)
							break;
						
						firstLetter = Character.toString(board[i-(k+1)][j].charAt(0));
						
						if(firstLetter.equals("W"))
							break;
						
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i-(k+1)) + Integer.toString(j);
						
						availableMoves.add(move);
						
						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("B") || firstLetter.equals("P"))
							break;
					}
					
					// check if it can move downwards
					for(int k=0; k<rookBlocks; k++)
					{
						if((i+(k+1)) == rows)
							break;
						
						firstLetter = Character.toString(board[i+(k+1)][j].charAt(0));
						
						if(firstLetter.equals("W"))
							break;
						
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i+(k+1)) + Integer.toString(j);
						
						availableMoves.add(move);
						
						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("B") || firstLetter.equals("P"))
							break;
					}
					
					// check if it can move on the left
					for(int k=0; k<rookBlocks; k++)
					{
						if((j-(k+1)) < 0)
							break;
						
						firstLetter = Character.toString(board[i][j-(k+1)].charAt(0));
						
						if(firstLetter.equals("W"))
							break;
						
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i) + Integer.toString(j-(k+1));
						
						availableMoves.add(move);
						
						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("B") || firstLetter.equals("P"))
							break;
					}
					
					// check of it can move on the right
					for(int k=0; k<rookBlocks; k++)
					{
						if((j+(k+1)) == columns)
							break;
						
						firstLetter = Character.toString(board[i][j+(k+1)].charAt(0));
						
						if(firstLetter.equals("W"))
							break;
						
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i) + Integer.toString(j+(k+1));
						
						availableMoves.add(move);
						
						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("B") || firstLetter.equals("P"))
							break;
					}
				}
				else // it is the king
				{
					// check if it can move upwards
					if((i-1) >= 0)
					{
						firstLetter = Character.toString(board[i-1][j].charAt(0));
						
						if(!firstLetter.equals("W"))
						{
							move = Integer.toString(i) + Integer.toString(j) + 
								   Integer.toString(i-1) + Integer.toString(j);
								
							availableMoves.add(move);	
						}
					}
					
					// check if it can move downwards
					if((i+1) < rows)
					{
						firstLetter = Character.toString(board[i+1][j].charAt(0));
						
						if(!firstLetter.equals("W"))
						{
							move = Integer.toString(i) + Integer.toString(j) + 
								   Integer.toString(i+1) + Integer.toString(j);
								
							availableMoves.add(move);	
						}
					}
					
					// check if it can move on the left
					if((j-1) >= 0)
					{
						firstLetter = Character.toString(board[i][j-1].charAt(0));
						
						if(!firstLetter.equals("W"))
						{
							move = Integer.toString(i) + Integer.toString(j) + 
								   Integer.toString(i) + Integer.toString(j-1);
								
							availableMoves.add(move);	
						}
					}
					
					// check if it can move on the right
					if((j+1) < columns)
					{
						firstLetter = Character.toString(board[i][j+1].charAt(0));
						
						if(!firstLetter.equals("W"))
						{
							move = Integer.toString(i) + Integer.toString(j) + 
								   Integer.toString(i) + Integer.toString(j+1);
								
							availableMoves.add(move);	
						}
					}
				}			
			}	
		}
        return availableMoves;
    }

    public ArrayList<String> blackMovesNewBoard(String[][] board) {
        ArrayList<String> availableMoves = new ArrayList<String>();

        String firstLetter = "";
		String secondLetter = "";
		String move = "";
				
		for(int i=0; i<rows; i++)
		{
			for(int j=0; j<columns; j++)
			{
				firstLetter = Character.toString(board[i][j].charAt(0));
				
				// if it there is not a black chess part in this position then keep on searching
				if(firstLetter.equals("W") || firstLetter.equals(" ") || firstLetter.equals("P"))
					continue;
				
				// check the kind of the white chess part
				secondLetter = Character.toString(board[i][j].charAt(1));
				
				if(secondLetter.equals("P"))	// it is a pawn
				{
					
					// check if it can move one vertical position ahead
					firstLetter = Character.toString(board[i+1][j].charAt(0));
					
					if(firstLetter.equals(" ") || firstLetter.equals("P"))
					{
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i+1) + Integer.toString(j);
						
						availableMoves.add(move);
					}
					
					// check if it can move crosswise to the left
					if(j!=0 && i!=rows-1)
					{
						firstLetter = Character.toString(board[i+1][j-1].charAt(0));
						
						if(!(firstLetter.equals("B") || firstLetter.equals(" ") || firstLetter.equals("P"))) {
							move = Integer.toString(i) + Integer.toString(j) + 
									   Integer.toString(i+1) + Integer.toString(j-1);
								
							availableMoves.add(move);
						}																	
					}
					
					// check if it can move crosswise to the right
					if(j!=columns-1 && i!=rows-1)
					{
						firstLetter = Character.toString(board[i+1][j+1].charAt(0));
						
						if(!(firstLetter.equals("B") || firstLetter.equals(" ") || firstLetter.equals("P"))) {
							move = Integer.toString(i) + Integer.toString(j) + 
									   Integer.toString(i+1) + Integer.toString(j+1);
								
							availableMoves.add(move);
						}
							
						
						
					}
				}
				else if(secondLetter.equals("R"))	// it is a rook
				{
					// check if it can move upwards
					for(int k=0; k<rookBlocks; k++)
					{
						if((i-(k+1)) < 0)
							break;
						
						firstLetter = Character.toString(board[i-(k+1)][j].charAt(0));
						
						if(firstLetter.equals("B"))
							break;
						
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i-(k+1)) + Integer.toString(j);
						
						availableMoves.add(move);
						
						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("W") || firstLetter.equals("P"))
							break;
					}
					
					// check if it can move downwards
					for(int k=0; k<rookBlocks; k++)
					{
						if((i+(k+1)) == rows)
							break;
						
						firstLetter = Character.toString(board[i+(k+1)][j].charAt(0));
						
						if(firstLetter.equals("B"))
							break;
						
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i+(k+1)) + Integer.toString(j);
						
						availableMoves.add(move);
						
						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("W") || firstLetter.equals("P"))
							break;
					}
					
					// check if it can move on the left
					for(int k=0; k<rookBlocks; k++)
					{
						if((j-(k+1)) < 0)
							break;
						
						firstLetter = Character.toString(board[i][j-(k+1)].charAt(0));
						
						if(firstLetter.equals("B"))
							break;
						
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i) + Integer.toString(j-(k+1));
						
						availableMoves.add(move);
						
						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("W") || firstLetter.equals("P"))
							break;
					}
					
					// check of it can move on the right
					for(int k=0; k<rookBlocks; k++)
					{
						if((j+(k+1)) == columns)
							break;
						
						firstLetter = Character.toString(board[i][j+(k+1)].charAt(0));
						
						if(firstLetter.equals("B"))
							break;
						
						move = Integer.toString(i) + Integer.toString(j) + 
							   Integer.toString(i) + Integer.toString(j+(k+1));
						
						availableMoves.add(move);
						
						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("W") || firstLetter.equals("P"))
							break;
					}
				}
				else // it is the king
				{
					// check if it can move upwards
					if((i-1) >= 0)
					{
						firstLetter = Character.toString(board[i-1][j].charAt(0));
						
						if(!firstLetter.equals("B"))
						{
							move = Integer.toString(i) + Integer.toString(j) + 
								   Integer.toString(i-1) + Integer.toString(j);
								
							availableMoves.add(move);	
						}
					}
					
					// check if it can move downwards
					if((i+1) < rows)
					{
						firstLetter = Character.toString(board[i+1][j].charAt(0));
						
						if(!firstLetter.equals("B"))
						{
							move = Integer.toString(i) + Integer.toString(j) + 
								   Integer.toString(i+1) + Integer.toString(j);
								
							availableMoves.add(move);	
						}
					}
					
					// check if it can move on the left
					if((j-1) >= 0)
					{
						firstLetter = Character.toString(board[i][j-1].charAt(0));
						
						if(!firstLetter.equals("B"))
						{
							move = Integer.toString(i) + Integer.toString(j) + 
								   Integer.toString(i) + Integer.toString(j-1);
								
							availableMoves.add(move);	
						}
					}
					
					// check if it can move on the right
					if((j+1) < columns)
					{
						firstLetter = Character.toString(board[i][j+1].charAt(0));
						
						if(!firstLetter.equals("B"))
						{
							move = Integer.toString(i) + Integer.toString(j) + 
								   Integer.toString(i) + Integer.toString(j+1);
								
							availableMoves.add(move);	
						}
					}
				}			
			}	
		}
        return availableMoves;
    }

    private boolean cutoffTest(int depth) {
        return depth >= maxDepth;
    }

    private boolean abCutoffTest(int depth) {
        return depth >= abMaxDepth;
    }

	public int[] convertMoveToInt(String move) {
		int[] intMove = new int[4];

		for(int i = 0; i < move.length(); i++)
			intMove[i] = Integer.parseInt(String.valueOf(move.charAt(i)));  

		return intMove;
	}

	private String[][] copyBoard(String[][] mat) {
		int i, j;
		String[][] copy = new String[mat.length][mat[0].length];

		for(i = 0; i < mat.length; i++) {
            for(j = 0; j < mat[i].length; j++) {
                copy[i][j] = mat[i][j];
            }
        }

        return copy;
	}

	public makeMoveRet makeMoveInCopy(String[][] matrix, int x1, int y1, int x2, int y2, int prizeX, int prizeY) {
        makeMoveRet moveRet = new makeMoveRet();
		String chesspart = Character.toString(matrix[x1][y1].charAt(1));
        double bonusScore = 0;
		
		boolean pawnLastRow = false;
		
        if(matrix[x1][y1] == " " || matrix[x1][y1] == "" || matrix[x1][y1] == "P") {
            System.out.println("Sorry, this program is bad");
        }

        //check if we steped on a present.
        if(matrix[x2][y2] == "P") {
            String color = Character.toString(matrix[x1][y1].charAt(0));
            if (color == "W")
                bonusScore = presentScore;
            else
                bonusScore = -presentScore;
        }

		// check if it is a move that has made a move to the last line
		if(chesspart.equals("P"))
			if( (x1==rows-2 && x2==rows-1) || (x1==1 && x2==0) )
			{
				matrix[x2][y2] = " ";	// in a case an opponent's chess part has just been captured
				matrix[x1][y1] = " ";
				pawnLastRow = true;
			}
		
		// otherwise
		if(!pawnLastRow)
		{
			matrix[x2][y2] = matrix[x1][y1];
			matrix[x1][y1] = " ";
		}
		
		// check if a prize has been added in the game
		if(prizeX != noPrize)
			matrix[prizeX][prizeY] = "P";

        moveRet.newBoard = matrix;
        moveRet.bonus = bonusScore;
		return moveRet;
	}

	public boolean gameOver(String[][] chessboard) {
		int i, j, kingCounter = 0;
		boolean onlyKingsLeft = true;
		for(i = 0; i < chessboard.length; i++) {
			for(j = 0; j < chessboard[i].length; j++) {
				if(chessboard[i][j] == "WK" || chessboard[i][j] == "BK")
					kingCounter++;
				else if(chessboard[i][j].charAt(0) == 'W' || chessboard[i][j].charAt(0) == 'B')
					onlyKingsLeft = false;
			}
		}

		assert(kingCounter == 1 || kingCounter == 2) : " Invalid position.";
		if(kingCounter < 1 || kingCounter > 2)
			System.out.println("Invalid Position!!!");
		return kingCounter != 2 || onlyKingsLeft;
	}

	public double evaluation(String[][] chessboard, double bonus) {
		double score = 0;
		int i, j;
		
		for(i = 0; i < chessboard.length; i++) {
			for(j = 0; j < chessboard[i].length; j++) {
				if(chessboard[i][j] == "WP")
					score += pawnScore;
				else if(chessboard[i][j] == "WR")
					score += rookScore;
				else if(chessboard[i][j] == "WK")
					score += kingScore;
				else if(chessboard[i][j] == "BP")
					score -= pawnScore;
				else if(chessboard[i][j] == "BR")
					score -= rookScore;
				else if(chessboard[i][j] == "BK")
					score -= kingScore;
			}
		}

		return score + bonus;
	}

	public void printBoard(String[][] b) {
		int i, j;
		for(i = 0; i < b.length; i++) {
			for(j = 0; j < b[i].length; j++) {
				String pos = b[i][j] == " " ? "_" : b[i][j];
				System.out.print(pos + "\t");
			}
			System.out.println();
		}
	}

	private void printMove(int [] intMove) {
		int i;
		for(i = 0; i < intMove.length; i++) {
			System.out.print(intMove[i]);
		}
		System.out.println();
	}

	private void printMoves(ArrayList<String> moves) {
		int i = 0;
		for(i = 0; i < moves.size(); i++) {
			System.out.print(moves.get(i) + ", ");
		}
		System.out.println();
	}
	/*
*/
	private ArrayList<String> forwardPruning(ArrayList<String> moves, int depth) {
		ArrayList<String> prunedMoves = new ArrayList<String>();
		if(depth < pruneDepth)
			return moves;
		if(depth >= pruneDepth && depth < singularExtensionDepth) {
			int branchesToKeep = moves.size() -  (int) Math.round(moves.size() * (depth - pruneDepth) / (singularExtensionDepth - pruneDepth)); // forward pruning relative to how deep we are.
			if(branchesToKeep == 0)
				branchesToKeep = 1;
			for(int i = 0; i < branchesToKeep; i++)
				prunedMoves.add(moves.get(i));
		} 
		if(depth >= singularExtensionDepth && depth <= abMaxDepth) {
			prunedMoves.add(moves.get(0)); // singular extension.
		}
		return prunedMoves;
	}

	public minimaxRet abMinimax(String[][] board, int depth, double alpha, double beta, boolean isWhite, double bonus) {
		ArrayList<String> moves = null;
		Utility u = new Utility();
        makeMoveRet moveRet = new makeMoveRet();
		minimaxRet ret = new minimaxRet();
		if(abCutoffTest(depth) || this.gameOver(board)) {
			ret.evaluation = this.evaluation(board, bonus);
			ret.move = "9999";
			return ret;
		}

		if(isWhite) {
			moves = this.forwardPruning(u.sortMoves(u.whiteMovesNewBoard(board), board), depth);
			ret.evaluation =  Integer.MIN_VALUE;
			for(int i = 0; i < moves.size(); i++) {
				String move = moves.get(i);
				int[] intMove = this.convertMoveToInt(move);
				String[][] newBoard = this.copyBoard(board);
				moveRet = this.makeMoveInCopy(newBoard, intMove[0], intMove[1], intMove[2], intMove[3], 9, 9);
				double eval = this.abMinimax(moveRet.newBoard, depth + 1, alpha, beta, false, moveRet.bonus + bonus).evaluation;
				if(ret.evaluation < eval) {
					ret.evaluation = eval;
					ret.move = move;
				}
				alpha = Math.max(alpha, ret.evaluation);
				if(beta <= alpha)
					break;
			}
			return ret;
		}
		
		else {
			moves = this.forwardPruning(u.sortMoves(u.blackMovesNewBoard(board), board), depth);
			ret.evaluation = Integer.MAX_VALUE;
			for(int i = 0; i < moves.size(); i++) {
				String move = moves.get(i);
				int[] intMove = this.convertMoveToInt(move);
				String[][] newBoard = this.copyBoard(board);
				moveRet = this.makeMoveInCopy(newBoard, intMove[0], intMove[1], intMove[2], intMove[3], 9, 9);
				double eval = this.abMinimax(moveRet.newBoard, depth + 1, alpha, beta, true, moveRet.bonus + bonus).evaluation;
				if(eval < ret.evaluation) {
					ret.evaluation = eval;
					ret.move = move;
				}
				beta = Math.min(beta, ret.evaluation);
				if(beta <= alpha)
					break;
			}
			return ret;
		}
	}

	public minimaxRet minimax(String[][] board, int depth, boolean isWhite, double bonus) {
		ArrayList<String> moves = null;
		Utility u = new Utility();
        makeMoveRet moveRet = new makeMoveRet();
		minimaxRet ret = new minimaxRet();
		if(this.cutoffTest(depth) || this.gameOver(board)) {
			ret.evaluation = this.evaluation(board, bonus);
			ret.move = "9999";
			return ret;
		}

		if(isWhite) {
			moves = this.forwardPruning(u.sortMoves(u.whiteMovesNewBoard(board), board), depth);
			ret.evaluation =  Integer.MIN_VALUE;
			for(int i = 0; i < moves.size(); i++) {
				String move = moves.get(i);
				int[] intMove = this.convertMoveToInt(move);
				String[][] newBoard = this.copyBoard(board);
				moveRet = this.makeMoveInCopy(newBoard, intMove[0], intMove[1], intMove[2], intMove[3], 9, 9);
				double eval = this.minimax(moveRet.newBoard, depth + 1, false, moveRet.bonus + bonus).evaluation;
				if(ret.evaluation < eval) {
					ret.evaluation = eval;
					ret.move = move;
				}
			}
			return ret;
		}
		
		else {
			moves = this.forwardPruning(u.sortMoves(u.blackMovesNewBoard(board), board), depth);
			ret.evaluation = Integer.MAX_VALUE;
			for(int i = 0; i < moves.size(); i++) {
				String move = moves.get(i);
				int[] intMove = this.convertMoveToInt(move);
				String[][] newBoard = this.copyBoard(board);
				moveRet = this.makeMoveInCopy(newBoard, intMove[0], intMove[1], intMove[2], intMove[3], 9, 9);
				double eval = this.minimax(moveRet.newBoard, depth + 1, true, moveRet.bonus + bonus).evaluation;
				if(eval < ret.evaluation) {
					ret.evaluation = eval;
					ret.move = move;
				}
			}
			return ret;
		}
	}

	private double UCB(MCTSData node, int parentSimulations) {
		if (node.n == 0)
			return Double.MAX_VALUE;
		else
			return node.w / node.n + c * Math.sqrt(Math.log(parentSimulations) / node.n);
	}

	private TreeNode findBestLeaf(TreeNode root) {
		TreeNode bestLeaf = root;
		List<TreeNode> children = bestLeaf.children;
		if(children == null || children.size() == 0) 
			return bestLeaf;
		double maximum = -1;
		int maxIndex = -1;
		for(int i = 0; i < children.size(); i++) {
			double nodeUCTcost = this.UCB(children.get(i).data, bestLeaf.data.n);
			if(nodeUCTcost > maximum) {
				maximum = nodeUCTcost;
				maxIndex = i;
			}
		}
		if(maxIndex == -1) {
			System.out.println("Something went wrong in MCTS leaf selection.");
		}
		return this.findBestLeaf(children.get(maxIndex));
	}

	private ArrayList<String> getMoves(String[][] board, boolean whiteToMove) {
		Utility u = new Utility();
		return whiteToMove ? u.whiteMovesNewBoard(board) : u.blackMovesNewBoard(board);
	}

	private boolean randomSimulation(String[][] board, boolean whitePlays, double bonus) {
		ArrayList<String> moves = null;	
		if(this.gameOver(board))
			return this.evaluation(board, bonus) > 0;
		moves = getMoves(board, whitePlays);
		if(moves.size() == 0) {
			/* We mentioned this in our report but there is no need to print it every time.
			System.out.println("ERROR\nNote that this problem is expected to happen when tens of thousands of simulations are run.");
			System.out.println("Unfortunately it is not mentioned in the problem statement how we should handle this.");
			String color = whitePlays ? "White" : "Black";
			System.out.println(color + " player has no valid moves but the game has not ended in this simulation.");
			System.out.println("The way we handled this is by supposing that the " + color + " player lost.");
			this.printBoard(board);
			*/
			return whitePlays ? true : false;
		}
		//make random move
		Random ran = new Random();
		int x = ran.nextInt(moves.size());
		int[] move = this.convertMoveToInt(moves.get(x));
		makeMoveRet newState = this.makeMoveInCopy(board, move[0], move[1], move[2], move[3], 9, 9);
		return this.randomSimulation(newState.newBoard, !whitePlays, newState.bonus + bonus);
	}

	private boolean rollout(TreeNode bestLeaf) {
		Utility u = new Utility();
		boolean whitePlays = bestLeaf.data.isWhite;
		if(bestLeaf.data.n == 0) {
			return randomSimulation(this.copyBoard(bestLeaf.data.board), whitePlays, 0);
		} else {
			ArrayList<String> moves = this.getMoves(bestLeaf.data.board, whitePlays);
			if(moves.size() == 0) {//This means that no moves are available but the game is not over either. We assume that the other color wins.
				//bestLeaf.data.n = Integer.MAX_VALUE; //make sure this is not chosen again.
				return !whitePlays;
			}
			for(int i = 0; i < moves.size(); i++) {
				int[] move = u.convertMoveToInt(moves.get(i));
				MCTSData newState = new MCTSData(0, 0, !whitePlays, moves.get(i), u.makeMoveInCopy(this.copyBoard(bestLeaf.data.board), move[0], move[1], move[2], move[3], 9, 9).newBoard );
				bestLeaf.addChild(newState);
			}
			return randomSimulation(this.copyBoard(bestLeaf.children.get(0).data.board), !whitePlays, 0);
		}
	}

	private void backpropagate(TreeNode bestLeaf, TreeNode root, boolean whiteWon) {
		TreeNode node = bestLeaf;
		while(node != root) {
			int winsToAdd = (whiteWon && node.data.isWhite) || (!whiteWon && !node.data.isWhite)  ? 1 : 0;
			node.data.w += winsToAdd;
			node.data.n += 1;
			node = node.parent;
		}
		int winsToAddToRoot = (whiteWon && root.data.isWhite) || (!whiteWon && !root.data.isWhite)  ? 1 : 0;
		root.data.w += winsToAddToRoot;
		root.data.n += 1;
		return;
	}

	private String findBestMove(TreeNode root) {
		int i = 0, bestIndex = -1, minimumOpponentWins = Integer.MAX_VALUE;
		for(i = 0; i < root.children.size(); i++) {
			int opponentWins = root.children.get(i).data.w;
			if(opponentWins < minimumOpponentWins) {
				minimumOpponentWins = opponentWins;
				bestIndex = i;
			}
		}
		return root.children.get(bestIndex).data.moveMadeFromParent;
	}

	public String MCTS(String[][] board, boolean whitePlays) {
		long startTime = System.currentTimeMillis();
		long currTime = 0;

		MCTSData rootData = new MCTSData(0, 0, whitePlays, "0000", board);
		MCTSTree = new TreeNode(rootData);
		int counter = 0;
		while(currTime < 6*1000 /*&& counter < 5000*/) {
			//System.out.println("Before:");
			//MCTSTree.printTree(MCTSTree);

			TreeNode bestLeaf = findBestLeaf(MCTSTree);
			boolean whiteWon = rollout(bestLeaf);
			if(bestLeaf.children.size() > 0) //then the rollout function created more states.
				bestLeaf = bestLeaf.children.get(0);
			this.backpropagate(bestLeaf, MCTSTree, whiteWon);
			currTime = (new Date()).getTime() - startTime;

			//System.out.println("After:");
			//MCTSTree.printTree(MCTSTree);
			counter++;
		}
		//System.out.println("Time: " + currTime + "ms.");
		//System.out.println("Iterations: " + counter + ".");
		return findBestMove(MCTSTree);
	}
}

class minimaxRet {
    double evaluation;
    String move;

    public minimaxRet() {

    }
}

class makeMoveRet {
    double bonus;
    String[][] newBoard;

    public makeMoveRet() {
        
    }
}