import java.util.List;
import java.util.LinkedList;

public class TreeNode {
    public MCTSData data = null;
    public TreeNode parent = null;
    public List<TreeNode> children = null;

    public TreeNode(MCTSData data) {
        this.data = new MCTSData(data.n, data.w, data.isWhite, data.moveMadeFromParent, data.board);
        this.children = new LinkedList<TreeNode>();
    }

    public TreeNode addChild(MCTSData childData) {
        TreeNode childNode = new TreeNode(childData);
        childNode.parent = this;
        this.children.add(childNode);
        return childNode;
    }
    
    public void printTree(TreeNode root) {
        root.data.printData();
        for(int i = 0; i < root.children.size(); i++) {
            printTree(root.children.get(i));
        }
    }
}