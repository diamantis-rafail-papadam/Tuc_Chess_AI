public class MCTSData {
    public String [][] board; //the chessboard.
    public boolean isWhite; //color of current player.
    public String moveMadeFromParent;
    public int n; //nomber of this node's simulations.
    public int w; //number of times that simulations in this node ended up winning.

    public MCTSData(int n, int w, boolean isWhite, String moveMadeFromParent, String [][] board) {
        this.n = n;
        this.w = w;
        this.isWhite = isWhite;
        this.moveMadeFromParent = moveMadeFromParent;
        this.board = board;
    }

    public void setNumOfParentSimulations(int n) {
        this.n = n;
    }

    public void setNumOfWins(int w) {
        this.w = w;
    }

    public void setIsWhite(boolean isWhite) {
        this.isWhite = isWhite;
    }

    public void setBoard(String[][] board) {
        this.board = board;
    }

    public int numOfSimulations() {
        return this.n;
    }

    public int numOfWins() {
        return this.w;
    }

    public boolean isWhite() {
        return this.isWhite;
    }

    public String[][] getBoard() {
        return this.board;
    }
    public void printData() {
        Utility u = new Utility();
        System.out.println("n = " + this.n + ", w = " + this.w + ", isWhite = " + this.isWhite + ", move from parent: " + this.moveMadeFromParent);
        u.printBoard(this.board);
    }
}
