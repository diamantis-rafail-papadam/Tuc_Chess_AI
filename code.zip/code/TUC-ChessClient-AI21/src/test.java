import java.util.*;

public class test {

    public test() {

    }

    private void printList(ArrayList<String> list) {
        for(int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i) + " ");
        }
    }
    public static void main(String args[]) {
        //System.out.println(Math.log(Math.exp(1)));
        /*
        test t = new test();
        String[] strings = {"string1", "string2", "string3", "string4", "string5"};
        Double[] doubles = {5.2, 5.1, 5.0, 5.3, 5.4};

        ArrayList<String> moves = new ArrayList<String>(Arrays.asList(strings));
        ArrayList<String> sortedMoves = moves;
		ArrayList<Double> moveScore = new ArrayList<Double>(Arrays.asList(doubles));

        t.printList(sortedMoves);
        System.out.println();
        Collections.sort(sortedMoves, Comparator.comparing(s -> moveScore.get(sortedMoves.indexOf(s))));
        t.printList(sortedMoves);
        t.printList(moves);
        */
        Hashtable<String, String> ht1 = new Hashtable<>();
  
        // Initialization of a Hashtable
        // using Generics
        Hashtable<Integer, String> ht2
            = new Hashtable<Integer, String>();
  
        // Inserting the Elements
        // using put() method
        ht1.put("BP", "1111");
        ht1.put("WP", "2222");
        ht1.put("BR", "3333");
  
        if(ht1.containsKey("BR")) {
            System.out.println("found it: " + ht1.get("BR"));
        }
        // Print mappings to the console
        System.out.println("Mappings of ht1 : " + ht1);
        System.out.println("Mappings of ht2 : " + ht2);
    }
}